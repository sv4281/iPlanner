/********************************************************************************
** Form generated from reading UI file 'signup.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SIGNUP_H
#define UI_SIGNUP_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_signup
{
public:
    QLabel *label_5;
    QLabel *label_7;
    QLabel *label_2;
    QCheckBox *checkBox;
    QPushButton *submit;
    QLabel *label_3;
    QLineEdit *username;
    QLabel *label_8;
    QLineEdit *password;
    QLabel *label_6;
    QLineEdit *name;
    QLineEdit *confirm;
    QLabel *label;
    QLabel *label_4;
    QLabel *eventName;

    void setupUi(QDialog *signup)
    {
        if (signup->objectName().isEmpty())
            signup->setObjectName("signup");
        signup->resize(726, 563);
        label_5 = new QLabel(signup);
        label_5->setObjectName("label_5");
        label_5->setGeometry(QRect(60, 140, 251, 16));
        QFont font;
        font.setFamilies({QString::fromUtf8("Rockwell")});
        label_5->setFont(font);
        label_5->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 4);"));
        label_7 = new QLabel(signup);
        label_7->setObjectName("label_7");
        label_7->setGeometry(QRect(110, 50, 451, 111));
        label_7->setPixmap(QPixmap(QString::fromUtf8("../../../Downloads/imgonline-com-ua-ReplaceColor-W5BXMGSQMUJVg1-removebg-preview-removebg-preview.png")));
        label_7->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(signup);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(260, 20, 151, 71));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Elephant")});
        font1.setPointSize(28);
        font1.setItalic(false);
        label_2->setFont(font1);
        checkBox = new QCheckBox(signup);
        checkBox->setObjectName("checkBox");
        checkBox->setGeometry(QRect(450, 290, 121, 22));
        checkBox->setFont(font);
        submit = new QPushButton(signup);
        submit->setObjectName("submit");
        submit->setGeometry(QRect(300, 410, 80, 41));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Myanmar Text")});
        font2.setPointSize(10);
        font2.setBold(true);
        submit->setFont(font2);
        submit->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(65, 0, 118);\n"
"border-radius: 5px;\n"
"border: none;\n"
"text-align: center;\n"
"padding: 5px 10px;\n"
"selection-background-color: rgb(255, 255, 255);\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(65, 0, 118);\n"
"background-color: rgb(255, 255, 255);\n"
"}"));
        label_3 = new QLabel(signup);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(220, 340, 241, 16));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("Rockwell")});
        font3.setBold(true);
        label_3->setFont(font3);
        label_3->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 4);"));
        label_3->setAlignment(Qt::AlignCenter);
        username = new QLineEdit(signup);
        username->setObjectName("username");
        username->setGeometry(QRect(110, 170, 151, 24));
        username->setInputMethodHints(Qt::ImhNone);
        username->setEchoMode(QLineEdit::Normal);
        username->setClearButtonEnabled(false);
        label_8 = new QLabel(signup);
        label_8->setObjectName("label_8");
        label_8->setGeometry(QRect(570, 480, 49, 16));
        password = new QLineEdit(signup);
        password->setObjectName("password");
        password->setGeometry(QRect(110, 240, 151, 24));
        password->setEchoMode(QLineEdit::Password);
        label_6 = new QLabel(signup);
        label_6->setObjectName("label_6");
        label_6->setGeometry(QRect(50, 280, 251, 16));
        label_6->setFont(font);
        label_6->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 4);"));
        name = new QLineEdit(signup);
        name->setObjectName("name");
        name->setGeometry(QRect(430, 170, 151, 24));
        confirm = new QLineEdit(signup);
        confirm->setObjectName("confirm");
        confirm->setGeometry(QRect(430, 240, 151, 24));
        confirm->setEchoMode(QLineEdit::Password);
        label = new QLabel(signup);
        label->setObjectName("label");
        label->setGeometry(QRect(430, 140, 141, 16));
        label->setFont(font);
        label->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 4);"));
        label_4 = new QLabel(signup);
        label_4->setObjectName("label_4");
        label_4->setGeometry(QRect(270, 250, 141, 16));
        label_4->setFont(font);
        label_4->setStyleSheet(QString::fromUtf8("color: rgb(255, 0, 4);"));
        eventName = new QLabel(signup);
        eventName->setObjectName("eventName");
        eventName->setGeometry(QRect(250, 490, 49, 16));
        label_7->raise();
        label_5->raise();
        label_2->raise();
        checkBox->raise();
        submit->raise();
        label_3->raise();
        username->raise();
        label_8->raise();
        password->raise();
        label_6->raise();
        name->raise();
        confirm->raise();
        label->raise();
        label_4->raise();
        eventName->raise();

        retranslateUi(signup);

        QMetaObject::connectSlotsByName(signup);
    } // setupUi

    void retranslateUi(QDialog *signup)
    {
        signup->setWindowTitle(QCoreApplication::translate("signup", "Dialog", nullptr));
        label_5->setText(QString());
        label_7->setText(QString());
        label_2->setText(QCoreApplication::translate("signup", "Sign Up", nullptr));
        checkBox->setText(QCoreApplication::translate("signup", "Show Password", nullptr));
        submit->setText(QCoreApplication::translate("signup", "Submit", nullptr));
        label_3->setText(QString());
        username->setInputMask(QString());
        username->setText(QString());
        username->setPlaceholderText(QCoreApplication::translate("signup", "Username", nullptr));
        label_8->setText(QString());
        password->setPlaceholderText(QCoreApplication::translate("signup", "Password", nullptr));
        label_6->setText(QString());
        name->setPlaceholderText(QCoreApplication::translate("signup", "Name", nullptr));
        confirm->setPlaceholderText(QCoreApplication::translate("signup", "Confirm Password", nullptr));
        label->setText(QString());
        label_4->setText(QString());
        eventName->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class signup: public Ui_signup {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SIGNUP_H
