/********************************************************************************
** Form generated from reading UI file 'home.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOME_H
#define UI_HOME_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDialog>
#include <QtWidgets/QLabel>
#include <QtWidgets/QListWidget>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_home
{
public:
    QLabel *label;
    QPushButton *pushButton;
    QLabel *label_2;
    QListWidget *listWidget;
    QPushButton *pushButton_2;

    void setupUi(QDialog *home)
    {
        if (home->objectName().isEmpty())
            home->setObjectName("home");
        home->resize(728, 479);
        label = new QLabel(home);
        label->setObjectName("label");
        label->setGeometry(QRect(230, -40, 271, 181));
        QFont font;
        font.setFamilies({QString::fromUtf8("Elephant")});
        font.setPointSize(48);
        label->setFont(font);
        pushButton = new QPushButton(home);
        pushButton->setObjectName("pushButton");
        pushButton->setGeometry(QRect(160, 390, 81, 61));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Myanmar Text")});
        font1.setPointSize(10);
        font1.setBold(true);
        pushButton->setFont(font1);
        pushButton->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(65, 0, 118);\n"
"border-radius: 10px;\n"
"border: none;\n"
"text-align: center;\n"
"padding: 4px 10px;\n"
"selection-background-color: rgb(255, 255, 255);\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(65, 0, 118);\n"
"background-color: rgb(255, 255, 255);\n"
"}"));
        label_2 = new QLabel(home);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(220, 210, 341, 101));
        QFont font2;
        font2.setFamilies({QString::fromUtf8("Myanmar Text")});
        font2.setPointSize(20);
        font2.setBold(true);
        label_2->setFont(font2);
        listWidget = new QListWidget(home);
        listWidget->setObjectName("listWidget");
        listWidget->setGeometry(QRect(40, 80, 621, 291));
        pushButton_2 = new QPushButton(home);
        pushButton_2->setObjectName("pushButton_2");
        pushButton_2->setGeometry(QRect(429, 393, 91, 61));
        QFont font3;
        font3.setFamilies({QString::fromUtf8("Myanmar Text")});
        font3.setBold(true);
        pushButton_2->setFont(font3);
        pushButton_2->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(65, 0, 118);\n"
"border-radius: 10px;\n"
"border: none;\n"
"text-align: center;\n"
"padding: 4px 10px;\n"
"selection-background-color: rgb(255, 255, 255);\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(65, 0, 118);\n"
"background-color: rgb(255, 255, 255);\n"
"}"));

        retranslateUi(home);

        QMetaObject::connectSlotsByName(home);
    } // setupUi

    void retranslateUi(QDialog *home)
    {
        home->setWindowTitle(QCoreApplication::translate("home", "Dialog", nullptr));
        label->setText(QCoreApplication::translate("home", "HOME", nullptr));
        pushButton->setText(QCoreApplication::translate("home", "Add Event", nullptr));
        label_2->setText(QString());
        pushButton_2->setText(QCoreApplication::translate("home", "Delete event", nullptr));
    } // retranslateUi

};

namespace Ui {
    class home: public Ui_home {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOME_H
