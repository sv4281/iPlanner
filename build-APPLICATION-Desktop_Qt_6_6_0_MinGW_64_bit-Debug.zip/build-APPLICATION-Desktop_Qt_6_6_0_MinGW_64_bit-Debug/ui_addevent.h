/********************************************************************************
** Form generated from reading UI file 'addevent.ui'
**
** Created by: Qt User Interface Compiler version 6.6.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDEVENT_H
#define UI_ADDEVENT_H

#include <QtCore/QDate>
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QDateEdit>
#include <QtWidgets/QDialog>
#include <QtWidgets/QGroupBox>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTimeEdit>

QT_BEGIN_NAMESPACE

class Ui_AddEvent
{
public:
    QGroupBox *groupBox;
    QLineEdit *eventname;
    QDateEdit *fromdate;
    QTimeEdit *fromtime;
    QTimeEdit *totime;
    QLabel *label_2;
    QLabel *label_3;
    QDateEdit *todate;
    QPushButton *okay;

    void setupUi(QDialog *AddEvent)
    {
        if (AddEvent->objectName().isEmpty())
            AddEvent->setObjectName("AddEvent");
        AddEvent->resize(780, 492);
        groupBox = new QGroupBox(AddEvent);
        groupBox->setObjectName("groupBox");
        groupBox->setGeometry(QRect(170, 40, 401, 341));
        QFont font;
        font.setFamilies({QString::fromUtf8("Rockwell")});
        font.setPointSize(18);
        font.setBold(true);
        groupBox->setFont(font);
        eventname = new QLineEdit(groupBox);
        eventname->setObjectName("eventname");
        eventname->setGeometry(QRect(70, 100, 261, 41));
        QFont font1;
        font1.setFamilies({QString::fromUtf8("Myanmar Text")});
        font1.setPointSize(9);
        font1.setBold(false);
        eventname->setFont(font1);
        eventname->setDragEnabled(true);
        fromdate = new QDateEdit(groupBox);
        fromdate->setObjectName("fromdate");
        fromdate->setGeometry(QRect(20, 200, 151, 41));
        fromdate->setMaximumDateTime(QDateTime(QDate(9999, 12, 31), QTime(23, 59, 59)));
        fromdate->setMinimumDate(QDate(2023, 9, 1));
        fromdate->setCurrentSection(QDateTimeEdit::YearSection);
        fromdate->setDate(QDate(2023, 10, 14));
        fromtime = new QTimeEdit(groupBox);
        fromtime->setObjectName("fromtime");
        fromtime->setGeometry(QRect(20, 270, 151, 41));
        totime = new QTimeEdit(groupBox);
        totime->setObjectName("totime");
        totime->setGeometry(QRect(210, 270, 151, 41));
        label_2 = new QLabel(groupBox);
        label_2->setObjectName("label_2");
        label_2->setGeometry(QRect(40, 170, 91, 21));
        label_3 = new QLabel(groupBox);
        label_3->setObjectName("label_3");
        label_3->setGeometry(QRect(260, 180, 49, 16));
        todate = new QDateEdit(groupBox);
        todate->setObjectName("todate");
        todate->setGeometry(QRect(210, 200, 151, 41));
        todate->setMinimumDate(QDate(2023, 9, 1));
        todate->setCurrentSection(QDateTimeEdit::YearSection);
        okay = new QPushButton(AddEvent);
        okay->setObjectName("okay");
        okay->setGeometry(QRect(330, 410, 71, 51));
        okay->setStyleSheet(QString::fromUtf8("QPushButton {\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(65, 0, 118);\n"
"border-radius: 10px;\n"
"border: none;\n"
"text-align: center;\n"
"padding: 4px 10px;\n"
"selection-background-color: rgb(255, 255, 255);\n"
"}\n"
"QPushButton:hover {\n"
"color: rgb(65, 0, 118);\n"
"background-color: rgb(255, 255, 255);\n"
"}"));

        retranslateUi(AddEvent);

        QMetaObject::connectSlotsByName(AddEvent);
    } // setupUi

    void retranslateUi(QDialog *AddEvent)
    {
        AddEvent->setWindowTitle(QCoreApplication::translate("AddEvent", "Dialog", nullptr));
        groupBox->setTitle(QCoreApplication::translate("AddEvent", "Add an event", nullptr));
        eventname->setPlaceholderText(QCoreApplication::translate("AddEvent", "Enter your event name", nullptr));
        fromdate->setDisplayFormat(QCoreApplication::translate("AddEvent", "yyyy-MM-dd", nullptr));
        fromtime->setDisplayFormat(QCoreApplication::translate("AddEvent", "hh:mm:ss", nullptr));
        totime->setDisplayFormat(QCoreApplication::translate("AddEvent", "hh:mm:ss", nullptr));
        label_2->setText(QCoreApplication::translate("AddEvent", "From", nullptr));
        label_3->setText(QCoreApplication::translate("AddEvent", "To", nullptr));
        todate->setDisplayFormat(QCoreApplication::translate("AddEvent", "yyyy-MM-dd", nullptr));
        okay->setText(QCoreApplication::translate("AddEvent", "OK", nullptr));
    } // retranslateUi

};

namespace Ui {
    class AddEvent: public Ui_AddEvent {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDEVENT_H
